<?php
use Blog\Person\User;

spl_autoload_register(function($class){
    $file = str_replace("\\", DIRECTORY_SEPARATOR, $class) . ".php";
    $pos = strrpos($file, "_");
    if($pos !== false)
    {
        $file = substr_replace($file, "\\", $pos, strlen("_"));
    }
    if(file_exists($file)){
        require $file;
    }
});

$usr = new User(0, "John", "Wick");
echo $usr->getFirstName()." ".$usr->getSecondName();
