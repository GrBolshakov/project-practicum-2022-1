<?php
require_once __DIR__ . './vendor/autoload.php';
use Grig\L2\Blog\Person\User;
use Grig\L2\Blog\Comment;
use Grig\L2\Blog\Post;

spl_autoload_register(function($class){
    $file = str_replace("\\", DIRECTORY_SEPARATOR, $class) . ".php";
    $pos = strrpos($file, "_");
    if($pos !== false)
    {
        $file = substr_replace($file, "\\", $pos, strlen("_"));
    }
    if(file_exists($file)){
        require $file;
    }
});

$usr = new User(0, "John", "Wick");
$post = new Post(0, 0, "First post.", "Some content");
$comment = new Comment(0, 0, 0, "Great!");
echo $usr->getFirstName()." ".$usr->getSecondName().PHP_EOL;
echo $post->getTitle()." ".$post->getText();
